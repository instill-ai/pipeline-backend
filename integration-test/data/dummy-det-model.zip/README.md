---
Task: Detection
Tags:
  - Detection
  - Test
---

# Test repo
This is dummy detection model used for testing purpose